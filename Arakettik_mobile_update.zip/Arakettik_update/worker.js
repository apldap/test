/*
 * Arakettik Cloudflare Worker
 *
 * Что делает этот Worker:
 * 1. Принимает заявки с сайта.
 * 2. Отправляет их тебе в Telegram с кнопками Принять / Отклонить.
 * 3. При одобрении сохраняет заявку в Cloudflare KV.
 * 4. Сайт получает одобренные мероприятия и организации через /events и /organizations.
 * 5. Для заявок с фотографией отправляет фотографию в Telegram и сохраняет сжатую копию в KV.
 *
 * ОБЯЗАТЕЛЬНЫЕ настройки Worker:
 * - Secret: TELEGRAM_BOT_TOKEN
 * - Variable: ADMIN_CHAT_ID = 1571821962
 * - Secret: WEBHOOK_SECRET
 * - KV Binding: ARAKETTIK_DB
 */

const JSON_HEADERS = {
  "Content-Type": "application/json; charset=UTF-8",
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type"
};

export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    if (request.method === "OPTIONS") {
      return new Response(null, { status: 204, headers: JSON_HEADERS });
    }

    try {
      // Проверка Worker в браузере.
      if (request.method === "GET" && url.pathname === "/") {
        return json({ success: true, service: "Arakettik API", status: "online" }, 200);
      }

      // Одобренные мероприятия для сайта.
      if (request.method === "GET" && url.pathname === "/events") {
        const events = await listByPrefix(env, "event:");
        return json({ success: true, events }, 200);
      }

      // Одобренные организации для сайта.
      if (request.method === "GET" && url.pathname === "/organizations") {
        const organizations = await listByPrefix(env, "organization:");
        return json({ success: true, organizations }, 200);
      }

      // Одноразовая установка Telegram webhook.
      // Открой URL /setup-webhook?secret=ТВОЙ_WEBHOOK_SECRET после деплоя.
      if (request.method === "GET" && url.pathname === "/setup-webhook") {
        const secret = url.searchParams.get("secret");
        if (!env.WEBHOOK_SECRET || secret !== env.WEBHOOK_SECRET) {
          return new Response("Forbidden", { status: 403 });
        }
        const webhookUrl = `${url.origin}/telegram-webhook?secret=${encodeURIComponent(env.WEBHOOK_SECRET)}`;
        const result = await telegramApi(env, "setWebhook", { url: webhookUrl });
        return json(result, result.ok ? 200 : 502);
      }

      // Telegram webhook.
      if (request.method === "POST" && url.pathname === "/telegram-webhook") {
        const secret = url.searchParams.get("secret");
        if (!env.WEBHOOK_SECRET || secret !== env.WEBHOOK_SECRET) {
          return new Response("Forbidden", { status: 403 });
        }

        const update = await request.json();
        if (update.callback_query) {
          await handleTelegramCallback(update.callback_query, env);
        }

        return new Response("OK", { status: 200 });
      }

      if (request.method !== "POST" || url.pathname !== "/") {
        return json({ success: false, message: "Not found" }, 404);
      }

      const data = await request.json();
      return await createApplication(data, env);
    } catch (error) {
      console.error("Worker error:", error);
      return json({
        success: false,
        message: "Ошибка Worker: " + (error?.message || "unknown error")
      }, 500);
    }
  }
};

async function createApplication(data, env) {
  if (!env.TELEGRAM_BOT_TOKEN || !env.ADMIN_CHAT_ID) {
    return json({
      success: false,
      message: "Не настроены TELEGRAM_BOT_TOKEN или ADMIN_CHAT_ID."
    }, 500);
  }

  const type = String(data.type || "event").trim() === "organization" ? "organization" : "event";
  const id = crypto.randomUUID();

  const application = {
    id,
    type,
    title: clean(data.title),
    organization: clean(data.organization),
    category: clean(data.category),
    categoryName: clean(data.categoryName),
    description: clean(data.description),
    activity: clean(data.activity),
    history: clean(data.history),
    address: clean(data.address),
    date: clean(data.date),
    time: clean(data.time),
    registrationLink: clean(data.registrationLink),
    website: clean(data.website),
    contact: clean(data.contact),
    socialLink: clean(data.socialLink),
    city: clean(data.city || "bishkek"),
    cityName: clean(data.cityName || data.city || "Не указан"),
    imageData: typeof data.imageData === "string" ? data.imageData : "",
    createdAt: new Date().toISOString()
  };

  if (!application.title || !application.description || !application.contact) {
    return json({ success: false, message: "Заполните название, описание и номер телефона." }, 400);
  }

  if (type === "event") {
    if (!application.organization || !application.date || !application.registrationLink) {
      return json({
        success: false,
        message: "Для мероприятия нужны организатор, дата и ссылка на регистрацию."
      }, 400);
    }
  } else {
    if (!application.activity || !application.address) {
      return json({
        success: false,
        message: "Для организации нужны направления деятельности и адрес."
      }, 400);
    }
  }

  // Храним заявку до решения модератора.
  await env.ARAKETTIK_DB.put(`pending:${id}`, JSON.stringify(application), {
    expirationTtl: 60 * 60 * 24 * 30
  });

  const buttons = {
    inline_keyboard: [[
      { text: "✅ Принять", callback_data: `approve:${id}` },
      { text: "❌ Отклонить", callback_data: `reject:${id}` }
    ]]
  };

  const caption = buildTelegramText(application);
  let telegramResult;

  if (application.imageData) {
    telegramResult = await sendTelegramPhoto(env, application.imageData, caption, buttons);
  } else {
    telegramResult = await telegramApi(env, "sendMessage", {
      chat_id: env.ADMIN_CHAT_ID,
      text: caption,
      reply_markup: buttons
    });
  }

  if (!telegramResult.ok) {
    await env.ARAKETTIK_DB.delete(`pending:${id}`);
    console.error("Telegram API error:", telegramResult);
    return json({
      success: false,
      message: "Telegram не принял заявку: " + (telegramResult.description || "неизвестная ошибка")
    }, 502);
  }

  return json({
    success: true,
    applicationId: id,
    message: "Заявка отправлена на модерацию."
  }, 200);
}

async function handleTelegramCallback(callback, env) {
  const adminId = String(env.ADMIN_CHAT_ID || "");
  const fromId = String(callback.from?.id || "");

  if (fromId !== adminId) {
    await telegramApi(env, "answerCallbackQuery", {
      callback_query_id: callback.id,
      text: "У вас нет доступа к модерации.",
      show_alert: true
    });
    return;
  }

  const [action, id] = String(callback.data || "").split(":");
  if (!id || !["approve", "reject"].includes(action)) {
    await telegramApi(env, "answerCallbackQuery", {
      callback_query_id: callback.id,
      text: "Некорректная заявка.",
      show_alert: true
    });
    return;
  }

  const raw = await env.ARAKETTIK_DB.get(`pending:${id}`);
  if (!raw) {
    await telegramApi(env, "answerCallbackQuery", {
      callback_query_id: callback.id,
      text: "Заявка уже обработана или истекла.",
      show_alert: true
    });
    return;
  }

  const application = JSON.parse(raw);

  if (action === "approve") {
    const published = normalizePublishedApplication(application);
    const prefix = application.type === "organization" ? "organization:" : "event:";
    await env.ARAKETTIK_DB.put(`${prefix}${id}`, JSON.stringify(published));
    await env.ARAKETTIK_DB.delete(`pending:${id}`);

    await updateTelegramModerationMessage(callback, env, "✅ ОДОБРЕНО И ОПУБЛИКОВАНО", application);
    await telegramApi(env, "answerCallbackQuery", {
      callback_query_id: callback.id,
      text: "Заявка опубликована на сайте!"
    });
    return;
  }

  await env.ARAKETTIK_DB.delete(`pending:${id}`);
  await updateTelegramModerationMessage(callback, env, "❌ ОТКЛОНЕНО", application);
  await telegramApi(env, "answerCallbackQuery", {
    callback_query_id: callback.id,
    text: "Заявка отклонена."
  });
}

function normalizePublishedApplication(application) {
  if (application.type === "organization") {
    return {
      id: application.id,
      region: application.city,
      regionName: application.cityName,
      name: application.title,
      description: application.description,
      activities: application.activity,
      contacts: application.contact,
      address: application.address,
      history: application.history || "Информация предоставлена организатором.",
      website: application.website,
      socialLink: application.socialLink,
      imageData: application.imageData,
      approvedId: application.id,
      approvedAt: new Date().toISOString()
    };
  }

  return {
    id: application.id,
    approvedId: application.id,
    city: application.city,
    cityName: application.cityName,
    title: application.title,
    organization: application.organization,
    category: application.category,
    categoryName: application.categoryName || application.category,
    date: formatDateForSite(application.date),
    rawDate: application.date,
    time: application.time,
    desc: application.description,
    description: application.description,
    address: application.address,
    registrationLink: application.registrationLink,
    contact: application.contact,
    socialLink: application.socialLink,
    imageData: application.imageData,
    approvedAt: new Date().toISOString()
  };
}

function formatDateForSite(value) {
  if (!value) return "Дата уточняется";
  const date = new Date(`${value}T00:00:00`);
  if (Number.isNaN(date.getTime())) return value;
  return date.toLocaleDateString("ru-RU", {
    day: "2-digit",
    month: "long",
    year: "numeric"
  });
}

async function updateTelegramModerationMessage(callback, env, status, application) {
  const message = callback.message;
  if (!message) return;

  const newText = `${buildTelegramText(application)}\n\n${status}`;
  const isPhotoMessage = Boolean(message.photo);

  if (isPhotoMessage) {
    await telegramApi(env, "editMessageCaption", {
      chat_id: message.chat.id,
      message_id: message.message_id,
      caption: newText.slice(0, 1024),
      reply_markup: { inline_keyboard: [] }
    });
  } else {
    await telegramApi(env, "editMessageText", {
      chat_id: message.chat.id,
      message_id: message.message_id,
      text: newText,
      reply_markup: { inline_keyboard: [] }
    });
  }
}

function buildTelegramText(application) {
  const lines = [
    application.type === "organization" ? "🏢 НОВАЯ ЗАЯВКА НА ОРГАНИЗАЦИЮ" : "🚀 НОВАЯ ЗАЯВКА НА МЕРОПРИЯТИЕ",
    "",
    `📌 Название: ${application.title}`,
    `🏢 Организатор: ${application.organization || "Не указан"}`,
    `📍 Город: ${application.cityName}`,
    application.type === "event" ? `🏷 Категория: ${application.categoryName || application.category}` : `🎯 Направления: ${application.activity}`,
    application.date ? `📅 Дата: ${application.date}` : null,
    application.time ? `⏰ Время: ${application.time}` : null,
    application.address ? `📍 Адрес / место: ${application.address}` : null,
    "",
    "📝 Описание:",
    application.description,
    application.history ? `\n📖 История:\n${application.history}` : null,
    "",
    `📞 Телефон: ${application.contact}`,
    application.registrationLink ? `🔗 Регистрация: ${application.registrationLink}` : null,
    application.website ? `🌐 Сайт: ${application.website}` : null,
    application.socialLink ? `📱 Соцсети: ${application.socialLink}` : null,
    "",
    "⏳ Статус: ожидает модерации"
  ].filter(Boolean);

  return lines.join("\n");
}

async function sendTelegramPhoto(env, dataUrl, caption, replyMarkup) {
  const match = dataUrl.match(/^data:(image\\/[^;]+);base64,(.+)$/);
  if (!match) {
    return { ok: false, description: "Некорректное изображение." };
  }

  const mime = match[1];
  const bytes = base64ToUint8Array(match[2]);
  const blob = new Blob([bytes], { type: mime });
  const form = new FormData();
  form.append("chat_id", String(env.ADMIN_CHAT_ID));
  form.append("photo", blob, "arakettik.jpg");
  form.append("caption", caption.slice(0, 1024));
  form.append("reply_markup", JSON.stringify(replyMarkup));

  const response = await fetch(`https://api.telegram.org/bot${env.TELEGRAM_BOT_TOKEN}/sendPhoto`, {
    method: "POST",
    body: form
  });
  return await response.json();
}

async function telegramApi(env, method, body) {
  const response = await fetch(`https://api.telegram.org/bot${env.TELEGRAM_BOT_TOKEN}/${method}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body)
  });
  return await response.json();
}

async function listByPrefix(env, prefix) {
  if (!env.ARAKETTIK_DB) return [];
  const result = await env.ARAKETTIK_DB.list({ prefix });
  const values = await Promise.all(result.keys.map(async key => {
    const value = await env.ARAKETTIK_DB.get(key.name);
    try { return JSON.parse(value); } catch { return null; }
  }));
  return values.filter(Boolean);
}

function base64ToUint8Array(base64) {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return bytes;
}

function clean(value) {
  return String(value ?? "").trim();
}

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: JSON_HEADERS
  });
}
